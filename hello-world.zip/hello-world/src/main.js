import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";

//console.log(OrbitControls);

const scene = new THREE.Scene();

const textureloader = new THREE.TextureLoader();

const cubeGeometry = new THREE.BoxGeometry(1, 1, 1, 2, 2, 2);

//const material = new THREE.MeshBasicMaterial({
//  color: "green",
//  transparent: true,
// opacity: 0.6,
//});
//const geometry = new THREE.PlaneGeometry(1, 1, 1, 1);

//const material = new THREE.MeshBasicMaterial({
// color: "Green",
// transparent: true,
//  opacity: 0.4,
//});

//create costum geometry
//const vertices = new Float32Array([0, 0, 0, 0, 2, 0, 2, 0, 0]);

//const bufferAttribute = new THREE.BufferAttribute(vertices, 3);
//const geometry = new THREE.BufferGeometry();
//geometry.setAttribute("position", bufferAttribute);

const cubeMaterial = new THREE.MeshPhongMaterial({
  color: "yellow",
  transparent: true,
  opacity: 0.5,
});

//const textureTest = textureLoader.load("url");
//console.log(textureTest);

const cubeMesh = new THREE.Mesh(cubeGeometry, cubeMaterial);
//const cubeMesh2 = new THREE.Mesh(cubeGeometry, cubeMaterial);
//cubeMesh2.position.x = 1.5;
scene.add(cubeMesh);
//scene.add(cubeMesh2);

//light
const ambientlight = new THREE.AmbientLight("darkorange", 0.6);
scene.add(ambientlight);

const directionalLight = new THREE.DirectionalLight("darkorange", 1);
directionalLight.position.set(5, 5, 5);
scene.add(directionalLight);

//initialize the camera
//cubeMesh.rotation.reorder("YXZ");

//cubeMesh.position.x = 1;
//cubeMesh.position.y = 1;
//cubeMesh.scale.x = 1;

//cubeMesh.rotation.y = THREE.MathUtils.degToRad(90);
//cubeMesh.rotation.x = THREE.MathUtils.degToRad(45);

//const tempVector = new THREE.Vector3(0, 1, 0);

//cubeMesh.position.copy(tempVector);

//const axesHelper = new THREE.AxesHelper(2);
//scene.add(axesHelper);
//intiate the camera
const camera = new THREE.PerspectiveCamera(
  50,
  window.innerWidth / window.innerHeight,
  0.1,
  200
);

//const aspectRatio = window.innerWidth / window.innerHeight;
//const camera = new THREE.OrthographicCamera(
//  -1 * aspectRatio,
//  1 * aspectRatio,
//  1,
//  -1,
//  0.1,
//  200
//);
camera.position.z = 5;

//intialize the renderer
const canvas = document.querySelector("canvas.threejs");
const renderer = new THREE.WebGLRenderer({
  canvas: canvas,
  antialias: true,
});
renderer.setSize(window.innerWidth, window.innerHeight);
const maxPixelRatio = Math.min(window.devicePixelRatio, 2);
renderer.setPixelRatio(maxPixelRatio);

//initiate the controls
const controls = new OrbitControls(camera, canvas);
controls.enableDamping = true;
//controls.autoRotate = true;

window.addEventListener("resize", () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

//initial the clock
const clock = new THREE.Clock();
let previousTime = 0;

//render the scene
const renderloop = () => {
  const currentTime = clock.getElapsedTime();
  const delta = currentTime - previousTime;
  previousTime = currentTime;

  cubeMesh.rotation.y += THREE.MathUtils.degToRad(1) * delta * 20;

  //cubeMesh.scale.x = Math.sin(currentTime) * 20 + 2;
  //cubeMesh.position.x = Math.sin(currentTime) + 2;
  controls.update();
  renderer.render(scene, camera);
  window.requestAnimationFrame(renderloop);
};

renderloop();

renderer.setSize(window.innerWidth, window.innerHeight);
